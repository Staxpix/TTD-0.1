//
//  ColorExtension.swift
//  TTD-0.1
//
//  Created by Daniel Enning on 10.04.21.
//

import SwiftUI

extension Color {
    static let ttdWhite = Color(red: 255, green: 255, blue: 235)
}

//(red: 255, green: 255, blue: 235)
