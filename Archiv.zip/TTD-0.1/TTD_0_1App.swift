//
//  TTD_0_1App.swift
//  TTD-0.1
//
//  Created by Daniel Enning on 10.04.21.
//

import SwiftUI

@main
struct TTD_0_1App: App {
    var body: some Scene {
        WindowGroup {
            StartTabView()
        }
    }
}


//PersonsCardView(name: "fjdkalö", status: "jfdkaö", image: "oli")
